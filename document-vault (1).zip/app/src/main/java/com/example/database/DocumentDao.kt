package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY dateAdded DESC")
    fun getAllDocuments(): Flow<List<Document>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getDocumentById(id: Int): Document?

    @Query("""
        SELECT * FROM documents 
        WHERE title LIKE :query 
        OR extractedText LIKE :query 
        OR category LIKE :query 
        OR summary LIKE :query 
        OR keyDetails LIKE :query
        ORDER BY dateAdded DESC
    """)
    fun searchDocuments(query: String): Flow<List<Document>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document): Long

    @Delete
    suspend fun deleteDocument(document: Document)
}
