package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val imagePath: String, // Local storage file path for the scanned image
    val extractedText: String,
    val summary: String,
    val keyDetails: String, // Structured AI elements (e.g., Dates, Amounts, Names)
    val isFavorite: Boolean = false,
    val isPinned: Boolean = false,
    val isLocked: Boolean = false,
    val notes: String = ""
)
