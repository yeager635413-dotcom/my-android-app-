package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.database.AppDatabase
import com.example.database.Document
import com.example.database.DocumentRepository
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DocumentViewModel
import com.example.viewmodel.ScanState
import com.example.api.VaultSettings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.input.KeyboardType
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private var tempImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Set up local Room DB and repo
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = DocumentRepository(database.documentDao())
        
        // Instantiate our StateFlow ViewModel combining the repository data
        val viewModel: DocumentViewModel by viewModels {
            DocumentViewModel.Factory(repository, applicationContext)
        }

        setContent {
            val context = LocalContext.current
            
            // Dynamic theme controller with instant UI updates
            var themeModeVal by remember { mutableStateOf(VaultSettings.getThemeMode(context)) }
            val systemDark = isSystemInDarkTheme()
            val darkTheme = when (themeModeVal) {
                "dark" -> true
                "light" -> false
                else -> systemDark
            }

            MyApplicationTheme(darkTheme = darkTheme) {
                val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
                
                // Active launcher for System Image Library Picker
                val pickMedia = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri ->
                    if (uri != null) {
                        val bitmap = uriToBitmap(context, uri)
                        if (bitmap != null) {
                            viewModel.processScannedImage(bitmap)
                        } else {
                            Toast.makeText(context, "Error decoding image file.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                // Active launcher for System Device Camera snapshots
                val takePicture = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.TakePicture()
                ) { success ->
                    if (success) {
                        tempImageUri?.let { uri ->
                            val bitmap = uriToBitmap(context, uri)
                            if (bitmap != null) {
                                viewModel.processScannedImage(bitmap)
                            } else {
                                Toast.makeText(context, "Error reading captured photo.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Trigger camera taking and securely cache destination URI
                val onLaunchCamera = {
                    try {
                        val uri = createImageUri(context)
                        tempImageUri = uri
                        takePicture.launch(uri)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Failed to launch Camera: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }

                val onLaunchGallery = {
                    pickMedia.launch("image/*")
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    if (!isVaultUnlocked) {
                        VaultLockScreen(
                            isSetup = VaultSettings.getVaultPin(context).isEmpty(),
                            onUnlockSuccess = { pin ->
                                val ok = viewModel.verifyPinAndUnlock(pin)
                                if (!ok) {
                                    Toast.makeText(context, "Incorrect PIN, access denied.", Toast.LENGTH_SHORT).show()
                                }
                                ok
                            },
                            onSetupSuccess = { pin ->
                                VaultSettings.setVaultPin(context, pin)
                                VaultSettings.setPinLockEnabled(context, true)
                                viewModel.resetLockState()
                                Toast.makeText(context, "Passcode configured successfully!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    } else {
                        // Parent View Layout
                        Scaffold(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("main_screen"),
                            contentWindowInsets = WindowInsets.safeDrawing
                        ) { innerPadding ->
                            DocumentVaultDashboard(
                                viewModel = viewModel,
                                modifier = Modifier.padding(innerPadding),
                                onLaunchCamera = onLaunchCamera,
                                onLaunchGallery = onLaunchGallery,
                                onThemeChanged = { newTheme ->
                                    themeModeVal = newTheme
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun createImageUri(context: Context): Uri {
        val directory = File(context.cacheDir, "images")
        if (!directory.exists()) {
            directory.mkdirs()
        }
        val file = File(directory, "camera_capture.jpg")
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    private fun uriToBitmap(context: Context, uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.isMutableRequired = true
                }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

@Composable
fun DocumentVaultDashboard(
    viewModel: DocumentViewModel,
    modifier: Modifier = Modifier,
    onLaunchCamera: () -> Unit,
    onLaunchGallery: () -> Unit,
    onThemeChanged: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val documents by viewModel.documentsState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val scanState by viewModel.scanState.collectAsStateWithLifecycle()

    var showActionDialog by remember { mutableStateOf(false) }
    var selectedDocForDetail by remember { mutableStateOf<Document?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<Document?>(null) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        "All",
        "Favorites",
        "Secure Vault",
        "Receipts & Invoices",
        "Identity & Cards",
        "Medical & Health",
        "Academic & Certs",
        "Work & Professional",
        "Others"
    )

    // Check if API Key is configured anywhere
    val isApiKeyConfigured = remember(showSettingsDialog) {
        val userKey = VaultSettings.getCustomApiKey(context)
        val systemKey = com.example.BuildConfig.GEMINI_API_KEY
        userKey.isNotEmpty() || (systemKey.isNotEmpty() && systemKey != "MY_GEMINI_API_KEY")
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top App Bar Profile Header with clickable settings gear
            HeaderBlock(
                totalCount = documents.size,
                onSettingsClick = { showSettingsDialog = true }
            )

            // Alert Banner if Gemini is not ready yet
            if (!isApiKeyConfigured) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { showSettingsDialog = true },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini Key Required",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = "Document scanning will fail without an API Key. Tap here to set up your key safely in seconds.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                            )
                        }
                        IconButton(onClick = { showSettingsDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Configure Key",
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // Search Bar Component
            SearchBarSection(
                query = searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) }
            )

            // Horizontal Filter Chips Block
            CategorySelectorList(
                categories = categories,
                selectedCategory = selectedCategory,
                onCategorySelect = { viewModel.setSelectedCategory(it) }
            )

            // Expanded Storage Insights Panel (renders beautiful vault stats dynamically)
            if (documents.isNotEmpty() && searchQuery.isEmpty() && selectedCategory == "All") {
                VaultStatsPanel(documents = documents)
            }

            // Documents List Container
            if (documents.isEmpty()) {
                EmptyStateView()
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .testTag("documents_list"),
                    contentPadding = PaddingValues(bottom = 88.dp, start = 16.dp, end = 16.dp, top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(documents, key = { it.id }) { doc ->
                        DocumentItemCard(
                            document = doc,
                            searchQuery = searchQuery,
                            onToggleFavorite = { viewModel.toggleFavorite(doc) },
                            onTogglePinned = { viewModel.togglePinned(doc) },
                            onClick = {
                                // Locked documents require a PIN if set up and currently not unlocked session-wise
                                if (doc.isLocked && VaultSettings.isPinLockEnabled(context)) {
                                    // Custom document challenge
                                    selectedDocForDetail = doc
                                } else {
                                    selectedDocForDetail = doc
                                }
                            },
                            onLongClick = { showDeleteConfirmDialog = doc }
                        )
                    }
                }
            }
        }

        // Floating Action Button to trigger Scanning / Fetching
        FloatingActionButton(
            onClick = { showActionDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("scan_fab"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Scan Document")
                Text(
                    text = "Scan",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // --- SHEET & DIALOG CONTROLS ---

        // Scan Source Action Dialog
        if (showActionDialog) {
            SourcePickerSheet(
                onDismiss = { showActionDialog = false },
                onCameraSelected = {
                    showActionDialog = false
                    onLaunchCamera()
                },
                onGallerySelected = {
                    showActionDialog = false
                    onLaunchGallery()
                }
            )
        }

        // Loading Overlay during analysis
        when (scanState) {
            is ScanState.Processing -> {
                ProcessingOverlay()
            }
            is ScanState.Error -> {
                val msg = (scanState as ScanState.Error).message
                AlertDialog(
                    onDismissRequest = { viewModel.clearScanState() },
                    title = { Text("OCR Analysis Failed") },
                    text = { Text(msg) },
                    confirmButton = {
                        TextButton(onClick = { viewModel.clearScanState() }) {
                            Text("OK")
                        }
                    }
                )
            }
            is ScanState.Success -> {
                val doc = (scanState as ScanState.Success).document
                LaunchedEffect(scanState) {
                    Toast.makeText(context, "Successfully saved: ${doc.title}", Toast.LENGTH_LONG).show()
                    viewModel.clearScanState()
                }
            }
            else -> {}
        }

        if (showSettingsDialog) {
            SettingsDialog(
                onDismiss = { showSettingsDialog = false },
                onThemeChanged = { dir ->
                    onThemeChanged(dir)
                },
                viewModel = viewModel
            )
        }

        // Detail Slide-Up Dialog Detail View
        selectedDocForDetail?.let { doc ->
            DocumentDetailOverlay(
                document = doc,
                searchQuery = searchQuery,
                onDismiss = { selectedDocForDetail = null },
                onDelete = {
                    selectedDocForDetail = null
                    showDeleteConfirmDialog = doc
                },
                onToggleFavorite = { viewModel.toggleFavorite(doc) },
                onTogglePinned = { viewModel.togglePinned(doc) },
                onToggleLocked = { viewModel.toggleLocked(doc) },
                onUpdateDocument = { viewModel.updateDocument(it) }
            )
        }

        // Safe Delete Confirmation
        showDeleteConfirmDialog?.let { doc ->
            AlertDialog(
                onDismissRequest = { showDeleteConfirmDialog = null },
                icon = { Icon(Icons.Default.Warning, contentDescription = "Warning", tint = MaterialTheme.colorScheme.error) },
                title = { Text("Delete Document") },
                text = { Text("Are you sure you want to permanently delete \"${doc.title}\"? This action deleted local cache copy as well and cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteDocument(doc)
                            showDeleteConfirmDialog = null
                            Toast.makeText(context, "Document deleted", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmDialog = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun HeaderBlock(totalCount: Int, onSettingsClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        Color.Transparent
                     )
                )
            )
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Doc Vault",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "AI-powered paper archivist & secure locker",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$totalCount",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "docs",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Vault Settings",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SearchBarSection(
    query: String,
    onQueryChange: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("search_bar"),
        placeholder = { Text("Search title, OCR content, summaries, key details...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { 
                    onQueryChange("")
                    focusManager.clearFocus()
                }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear Search")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = {
            focusManager.clearFocus()
            keyboardController?.hide()
        })
    )
}

@Composable
fun CategorySelectorList(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { category ->
            val isSelected = category == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelect(category) },
                label = { Text(category) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(10.dp),
                border = null
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DocumentItemCard(
    document: Document,
    searchQuery: String,
    onToggleFavorite: () -> Unit,
    onTogglePinned: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val dateString = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(document.dateAdded))

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("document_card_${document.id}")
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left - Document Thumbnail frame (preserves negative space, elegant clipping)
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = document.imagePath,
                    contentDescription = "Document Thumbnail",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                
                // Bottom Category Icon overlay anchor
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(topStart = 6.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(document.category),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right - Title, description summaries, badge details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (document.isPinned) {
                            Icon(
                                imageVector = Icons.Default.Star, // Star used as pin fallback/indicator
                                contentDescription = "Pinned",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        if (document.isLocked) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked document",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = highlightMatches(
                                text = document.title,
                                query = searchQuery,
                                highlightColor = Color(0xFFFFEB3B),
                                textColor = Color.Black
                            ),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateString,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))
                
                // Fine Category label & Favorite button row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = document.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Quick Pin Toggle
                        IconButton(
                            onClick = onTogglePinned,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = if (document.isPinned) Icons.Default.Star else Icons.Default.Star, // Visual alternative or use tint
                                contentDescription = "Toggle Pin",
                                tint = if (document.isPinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        
                        // Favorite Toggle
                        IconButton(
                            onClick = onToggleFavorite,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Favorite Toggle",
                                tint = if (document.isFavorite) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // OCR Summary Text block
                Text(
                    text = highlightMatches(
                        text = if (document.notes.isNotBlank()) "[Note] ${document.notes}\n${document.summary}" else document.summary,
                        query = searchQuery,
                        highlightColor = Color(0xFFFFEB3B),
                        textColor = Color.Black
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                // Snapped Match Snippet from OCR text
                val snippet = getSearchSnippet(document.extractedText, searchQuery)
                if (snippet != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Matched inside text",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(10.dp)
                                )
                                Text(
                                    text = "MATCHED TEXT",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    ),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = highlightMatches(
                                    text = snippet,
                                    query = searchQuery,
                                    highlightColor = Color(0xFFFFEB3B),
                                    textColor = Color.Black
                                ),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.5.sp,
                                    lineHeight = 14.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Aesthetic Vector design using custom container circles
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "No documents icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Locker is Empty",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Tap 'Scan' below to take a photo of a physical document, receipt, card, or paper notes. Gemini will structure, organize, and OCR-parse details instantly.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

@Composable
fun SourcePickerSheet(
    onDismiss: () -> Unit,
    onCameraSelected: () -> Unit,
    onGallerySelected: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Sliding Sheet content
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = false) {}, // Consume taps
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Dragger bar accent
                    Box(
                        modifier = Modifier
                            .size(36.dp, 4.dp)
                            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f), CircleShape)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "Scan Physical Document",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Choose an input source to digitize paper records",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ActionCard(
                            title = "Camera Scan",
                            description = "Snap physical copy",
                            icon = Icons.Default.Add,
                            onClick = onCameraSelected,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        ActionCard(
                            title = "Gallery Import",
                            description = "Pick existing photo",
                            icon = Icons.Default.Home, // Fallback safe icon since folder is core pack
                            onClick = onGallerySelected,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ProcessingOverlay() {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 4.dp
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Running Gemini AI OCR...",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Scanning physical formats, analyzing text matrices, extracting key variables and structuring locker copies safely...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DocumentDetailOverlay(
    document: Document,
    searchQuery: String,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onToggleFavorite: () -> Unit = {},
    onTogglePinned: () -> Unit = {},
    onToggleLocked: () -> Unit = {},
    onUpdateDocument: (Document) -> Unit = {}
) {
    var activeTab by remember { mutableStateOf(0) } // 0 = OCR Text, 1 = Summary & Key details, 2 = Notes
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val imageFileExists = File(document.imagePath).exists()

    // Interactive Edit Mode Settings
    var isEditing by remember { mutableStateOf(false) }
    var editedTitle by remember { mutableStateOf(document.title) }
    var editedCategory by remember { mutableStateOf(document.category) }
    var editedOCR by remember { mutableStateOf(document.extractedText) }
    var editedSummary by remember { mutableStateOf(document.summary) }
    var editedKeyDetails by remember { mutableStateOf(document.keyDetails) }
    var editedNotes by remember { mutableStateOf(document.notes) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Highly Polished Top Control Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Go Back")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Vault Records",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Interactive Attribute Actions list
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        // Favorite toggle
                        IconButton(onClick = onToggleFavorite) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Favorite",
                                tint = if (document.isFavorite) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        }

                        // Pinned toggle
                        IconButton(onClick = onTogglePinned) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Pin Document",
                                tint = if (document.isPinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        }

                        // Locked toggle
                        IconButton(onClick = onToggleLocked) {
                            Icon(
                                imageVector = if (document.isLocked) Icons.Default.Lock else Icons.Default.Lock,
                                contentDescription = "Secure Lock",
                                tint = if (document.isLocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        }

                        // Edit Toggle
                        IconButton(
                            onClick = {
                                if (isEditing) {
                                    // Save the manual modifications
                                    onUpdateDocument(
                                        document.copy(
                                            title = editedTitle,
                                            category = editedCategory,
                                            extractedText = editedOCR,
                                            summary = editedSummary,
                                            keyDetails = editedKeyDetails,
                                            notes = editedNotes
                                        )
                                    )
                                    Toast.makeText(context, "Changes saved offline safely", Toast.LENGTH_SHORT).show()
                                }
                                isEditing = !isEditing
                            }
                        ) {
                            Icon(
                                imageVector = if (isEditing) Icons.Default.Check else Icons.Default.Edit,
                                contentDescription = if (isEditing) "Save Changes" else "Edit Record",
                                tint = if (isEditing) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Delete button
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Document", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Main Content Area (scrolling)
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Title and metadata block
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isEditing) {
                                    var showCatDropdown by remember { mutableStateOf(false) }
                                    Box {
                                        Button(
                                            onClick = { showCatDropdown = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                        ) {
                                            Text(editedCategory, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                        DropdownMenu(
                                            expanded = showCatDropdown,
                                            onDismissRequest = { showCatDropdown = false }
                                        ) {
                                            val cats = listOf("Receipts & Invoices", "Identity & Cards", "Medical & Health", "Academic & Certs", "Work & Professional", "Others")
                                            cats.forEach { catName ->
                                                DropdownMenuItem(
                                                    text = { Text(catName) },
                                                    onClick = {
                                                        editedCategory = catName
                                                        showCatDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = document.category,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                val creationDate = SimpleDateFormat("LLL d, yyyy 'at' hh:mm a", Locale.getDefault()).format(Date(document.dateAdded))
                                Text(
                                    text = creationDate,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (isEditing) {
                                OutlinedTextField(
                                    value = editedTitle,
                                    onValueChange = { editedTitle = it },
                                    label = { Text("Document Title") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            } else {
                                Text(
                                    text = highlightMatches(
                                        text = document.title,
                                        query = searchQuery,
                                        highlightColor = Color(0xFFFFEB3B),
                                        textColor = Color.Black
                                    ),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }

                    // Scanned visual digital copy section
                    item {
                        Text(
                            text = "Scanned Copy",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            if (imageFileExists) {
                                AsyncImage(
                                    model = document.imagePath,
                                    contentDescription = "Full scanned copy",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Original image not available in local filesystem.",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    // Tab bar content switcher
                    item {
                        TabRow(
                            selectedTabIndex = activeTab,
                            modifier = Modifier.fillMaxWidth(),
                            containerColor = Color.Transparent,
                            divider = {}
                        ) {
                            Tab(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                text = { Text("Extracted Text") }
                            )
                            Tab(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                text = { Text("AI Analysis") }
                            )
                            Tab(
                                selected = activeTab == 2,
                                onClick = { activeTab = 2 },
                                text = { Text("Notes") }
                            )
                        }
                    }

                    // Selected Tab Content Body
                    item {
                        Crossfade(targetState = activeTab) { state ->
                            when (state) {
                                0 -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                            .padding(16.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Extracted OCR String",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            IconButton(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(editedOCR))
                                                    Toast.makeText(context, "Copied OCR text to Clipboard", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Share, // safe core fallback for copies
                                                    contentDescription = "Copy Text",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.surfaceVariant)

                                        if (isEditing) {
                                            OutlinedTextField(
                                                value = editedOCR,
                                                onValueChange = { editedOCR = it },
                                                modifier = Modifier.fillMaxWidth(),
                                                minLines = 4,
                                                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                                            )
                                        } else {
                                            Text(
                                                text = if (document.extractedText.isBlank()) {
                                                    AnnotatedString("No readable OCR matches found.")
                                                } else {
                                                    highlightMatches(
                                                        text = document.extractedText,
                                                        query = searchQuery,
                                                        highlightColor = Color(0xFFFFEB3B),
                                                        textColor = Color.Black
                                                    )
                                                },
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontFamily = FontFamily.Monospace,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                lineHeight = 20.sp
                                            )
                                        }
                                    }
                                }
                                1 -> {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        // Summary Panel
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text(
                                                    text = "Smart Summary",
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                if (isEditing) {
                                                    OutlinedTextField(
                                                        value = editedSummary,
                                                        onValueChange = { editedSummary = it },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        minLines = 3
                                                    )
                                                } else {
                                                    Text(
                                                        text = highlightMatches(
                                                            text = document.summary,
                                                            query = searchQuery,
                                                            highlightColor = Color(0xFFFFEB3B),
                                                            textColor = Color.Black
                                                        ),
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }

                                        // Key structured Details
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text(
                                                    text = "Structured Variables",
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                if (isEditing) {
                                                    OutlinedTextField(
                                                        value = editedKeyDetails,
                                                        onValueChange = { editedKeyDetails = it },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        minLines = 3
                                                    )
                                                } else {
                                                    Text(
                                                        text = highlightMatches(
                                                            text = document.keyDetails,
                                                            query = searchQuery,
                                                            highlightColor = Color(0xFFFFEB3B),
                                                            textColor = Color.Black
                                                        ),
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        lineHeight = 22.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                2 -> {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text(
                                                    text = "Personal Secure Annotations",
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "Perfect for recording ledger references, physical tags, passwords, or personal validation details.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                                Spacer(modifier = Modifier.height(12.dp))
                                                
                                                OutlinedTextField(
                                                    value = editedNotes,
                                                    onValueChange = {
                                                        editedNotes = it
                                                        // Automatically save changes to note content instantly to keep it responsive
                                                        onUpdateDocument(document.copy(notes = it))
                                                    },
                                                    placeholder = { Text("Insert personal notes, codes, passwords, or tags here...") },
                                                    modifier = Modifier.fillMaxWidth(),
                                                    minLines = 4,
                                                    shape = RoundedCornerShape(10.dp)
                                                )
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text(
                                                    text = "⚠️ Notes are encrypted and stored locally offline in your sandbox.",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun getCategoryIcon(category: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when {
        category.contains("Receipt", ignoreCase = true) -> Icons.Default.Check
        category.contains("Identity", ignoreCase = true) -> Icons.Default.Person
        category.contains("Medical", ignoreCase = true) -> Icons.Default.Info
        category.contains("Academic", ignoreCase = true) -> Icons.Default.Star
        category.contains("Work", ignoreCase = true) -> Icons.Default.Settings
        else -> Icons.Default.List
    }
}

fun highlightMatches(
    text: String,
    query: String,
    highlightColor: Color,
    textColor: Color
): AnnotatedString {
    if (query.isBlank()) {
        return AnnotatedString(text)
    }
    return buildAnnotatedString {
        var startIdx = 0
        val lowerText = text.lowercase(Locale.getDefault())
        val lowerQuery = query.lowercase(Locale.getDefault())
        
        while (true) {
            val findIdx = lowerText.indexOf(lowerQuery, startIdx)
            if (findIdx == -1) {
                append(text.substring(startIdx))
                break
            }
            // Append non-matching part
            append(text.substring(startIdx, findIdx))
            // Append matching part highlighted
            withStyle(style = SpanStyle(background = highlightColor, color = textColor, fontWeight = FontWeight.Bold)) {
                append(text.substring(findIdx, findIdx + query.length))
            }
            startIdx = findIdx + query.length
        }
    }
}

fun getSearchSnippet(text: String, query: String, contextLength: Int = 30): String? {
    if (query.isBlank()) return null
    val index = text.indexOf(query, ignoreCase = true)
    if (index == -1) return null
    
    val start = (index - contextLength).coerceAtLeast(0)
    val end = (index + query.length + contextLength).coerceAtMost(text.length)
    
    val prefix = if (start > 0) "..." else ""
    val suffix = if (end < text.length) "..." else ""
    
    return prefix + text.substring(start, end).replace('\n', ' ') + suffix
}

@Composable
fun VaultStatsPanel(documents: List<Document>) {
    val totalCount = documents.size
    val lockedCount = documents.count { it.isLocked }
    val favoritesCount = documents.count { it.isFavorite }
    
    // Calculate storage size dynamically
    val totalSizeBytes = remember(documents) {
        documents.sumOf { doc ->
            try {
                val file = File(doc.imagePath)
                if (file.exists()) file.length() else 0L
            } catch (e: Exception) {
                0L
            }
        }
    }
    val totalSizeKb = (totalSizeBytes / 1024.0)
    val sizeText = if (totalSizeKb > 1024.0) {
        String.format("%.2f MB", totalSizeKb / 1024.0)
    } else {
        String.format("%.1f KB", totalSizeKb)
    }

    val securityCoverage = if (totalCount > 0) {
        (lockedCount * 100) / totalCount
    } else 0

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Secure Vault Overview",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = sizeText,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Ledger Offline Storage Size",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$securityCoverage%",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (securityCoverage > 75) Color(0xFF4CAF50) else if (securityCoverage > 30) Color(0xFFFF9800) else Color(0xFFF44336)
                    )
                    Text(
                        text = "Encrypted Security Tier",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { if (totalCount > 0) lockedCount.toFloat() / totalCount.toFloat() else 0f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                    Text(text = "$lockedCount secured", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFFE91E63), CircleShape))
                    Text(text = "$favoritesCount favorites", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun VaultLockScreen(
    isSetup: Boolean,
    onUnlockSuccess: (String) -> Boolean,
    onSetupSuccess: (String) -> Unit
) {
    var pinValue by remember { mutableStateOf("") }
    var setupStep by remember { mutableStateOf(1) } // 1 = Enter new, 2 = Confirm new
    var firstSetupPin by remember { mutableStateOf("") }
    var isErrorState by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 40.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Secured Vault Door",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isSetup) {
                    if (setupStep == 1) "Configure Vault Passcode" else "Confirm Vault Passcode"
                } else "Vault Securely Locked",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isSetup) {
                    if (setupStep == 1) "Choose a 4-digit PIN to isolate your archive on device storage" else "Confirm the 4-digit PIN again"
                } else "Please type your authorization PIN code to access vault items",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))
            
            // Render 4 round passcode indicators
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                (0..3).forEach { index ->
                    val filled = index < pinValue.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .border(2.dp, if (isErrorState) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, CircleShape)
                            .background(
                                color = if (filled) {
                                    if (isErrorState) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                } else Color.Transparent,
                                shape = CircleShape
                            )
                    )
                }
            }
        }

        // Numerical entry keypad
        Column(
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("Clear", "0", "Delete")
            )

            keys.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { char ->
                        Button(
                            onClick = {
                                isErrorState = false
                                when (char) {
                                    "Clear" -> pinValue = ""
                                    "Delete" -> {
                                        if (pinValue.isNotEmpty()) {
                                            pinValue = pinValue.dropLast(1)
                                        }
                                    }
                                    else -> {
                                        if (pinValue.length < 4) {
                                            pinValue += char
                                            if (pinValue.length == 4) {
                                                // Handle completion
                                                if (isSetup) {
                                                    if (setupStep == 1) {
                                                        firstSetupPin = pinValue
                                                        pinValue = ""
                                                        setupStep = 2
                                                    } else {
                                                        if (pinValue == firstSetupPin) {
                                                            onSetupSuccess(pinValue)
                                                        } else {
                                                            isErrorState = true
                                                            pinValue = ""
                                                            setupStep = 1
                                                            firstSetupPin = ""
                                                        }
                                                    }
                                                } else {
                                                    val success = onUnlockSuccess(pinValue)
                                                    if (!success) {
                                                        isErrorState = true
                                                        pinValue = ""
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.size(70.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (char == "Clear" || char == "Delete") Color.Transparent else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (char == "Clear" || char == "Delete") MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                        ) {
                            Text(
                                text = char,
                                style = if (char == "Clear" || char == "Delete") MaterialTheme.typography.bodySmall else MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsDialog(
    onDismiss: () -> Unit,
    onThemeChanged: (String) -> Unit,
    viewModel: DocumentViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var customApiKey by remember { mutableStateOf(VaultSettings.getCustomApiKey(context)) }
    var isPinLockEnabled by remember { mutableStateOf(VaultSettings.isPinLockEnabled(context)) }
    var showConfirmReset by remember { mutableStateOf(false) }
    var currentThemeState by remember { mutableStateOf(VaultSettings.getThemeMode(context)) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header Block inside Settings Dialog
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Vault Settings",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close Settings")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.surfaceVariant)

                // Settings Elements List scrollable container
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    
                    // SEGMENT 1: Gemini OCR Service Configuration
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "AI", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Gemini OCR AI Engine",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Text(
                            text = "To run highly sharp document parsing without relying on workspace defaults, you can inject your own Gemini API key below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = customApiKey,
                            onValueChange = { customApiKey = it },
                            placeholder = { Text("AIzaSy...") },
                            label = { Text("My Self-hosted Gemini Key") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            trailingIcon = {
                                Button(
                                    modifier = Modifier.padding(end = 6.dp),
                                    onClick = {
                                        VaultSettings.setCustomApiKey(context, customApiKey)
                                        Toast.makeText(context, "API Key updated successfully!", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Save", fontSize = 11.sp)
                                }
                            }
                        )
                        Text(
                            text = "💡 Get a free API Key immediately at ai.google.dev/gemini-api/key and paste it above to run local scanner processes.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                        )
                    }

                    // SEGMENT 2: Vault Passcode Lock
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = "Security", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Text(
                                    text = "Vault Authorization Screen",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Switch(
                                checked = isPinLockEnabled,
                                onCheckedChange = { checked ->
                                    if (checked && VaultSettings.getVaultPin(context).isEmpty()) {
                                        Toast.makeText(context, "Please configure a PIN passcode first!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        VaultSettings.setPinLockEnabled(context, checked)
                                        isPinLockEnabled = checked
                                        viewModel.resetLockState()
                                    }
                                }
                            )
                        }
                        Text(
                            text = "Isolate the general dashboard with a 4-digit PIN code. If enabled, the app asks for confirmation immediately on launcher startup or fold wake.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        var newPINSetup by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = newPINSetup,
                            onValueChange = { if (it.length <= 4) newPINSetup = it },
                            placeholder = { Text("e.g. 1234") },
                            label = { Text("Update Passcode Pin") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            trailingIcon = {
                                Button(
                                    modifier = Modifier.padding(end = 6.dp),
                                    onClick = {
                                        if (newPINSetup.length == 4) {
                                            VaultSettings.setVaultPin(context, newPINSetup)
                                            VaultSettings.setPinLockEnabled(context, true)
                                            isPinLockEnabled = true
                                            newPINSetup = ""
                                            viewModel.resetLockState()
                                            Toast.makeText(context, "Passcode configured & active!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "PIN code must be exactly 4 digits!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Text("Set", fontSize = 11.sp)
                                }
                            }
                        )
                    }

                    // SEGMENT 3: System Styling Choice Theme Toggle
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Theme", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Aesthetic Visual Theme",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Text(
                            text = "Toggle the system colors scheme. Dark mode utilizes modern cosmic slate backgrounds for lower eye fatigue.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("system" to "System Auto", "light" to "Dynamic Light", "dark" to "Cosmic Dark").forEach { (id, label) ->
                                val selected = currentThemeState == id
                                Button(
                                    onClick = {
                                        VaultSettings.setThemeMode(context, id)
                                        currentThemeState = id
                                        onThemeChanged(id)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(label, fontSize = 11.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }

                    // SEGMENT 4: Dynamic Phone Installation Help Instructions
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Install Guide", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = "Install Companion to Phone",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Text(
                            text = "To download this exact application onto your physical Android phone:\n" +
                                    "1. Tap the Settings icon in the top right of the Google AI Studio browser header.\n" +
                                    "2. Click 'Export Project/APK' inside the menu.\n" +
                                    "3. Download the compiled '.apk' file to your computer or phone.\n" +
                                    "4. Transfer it to your Android device, click to install, and allow installation of 'Unknown Sources' when prompted.\n" +
                                    "Enjoy your private secure Vault Ledger on the go!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }

                    // SEGMENT 5: Ledger Clean Reset Action
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showConfirmReset = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Purge Offline Vault Database")
                        }
                        Text(
                            text = "⚠️ Danger: This completely deletes the offline SQLite room database ledger and local Cached Document files irreversibly. Keep your backups secure.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.85f),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Close window button action
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Close Panel")
                }
            }

            if (showConfirmReset) {
                AlertDialog(
                    onDismissRequest = { showConfirmReset = false },
                    title = { Text("CONFIRM TOTAL PURGE") },
                    text = { Text("Are you absolutely sure you want to trigger a database wipe? Every single document and cached camera scan will be uninstalled permanently.") },
                    confirmButton = {
                        Button(
                            onClick = {
                                showConfirmReset = false
                                viewModel.clearAllData()
                                Toast.makeText(context, "Vault purged successfully", Toast.LENGTH_SHORT).show()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Wipe Ledger")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmReset = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}
