package com.example.api

import android.content.Context

object VaultSettings {
    private const val PREFS_NAME = "document_vault_settings"
    private const val KEY_CUSTOM_API_KEY = "custom_api_key"
    private const val KEY_VAULT_PIN = "vault_pin"
    private const val KEY_PIN_ENABLED = "pin_enabled"
    private const val KEY_THEME_MODE = "theme_mode"

    fun getCustomApiKey(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CUSTOM_API_KEY, "") ?: ""
    }

    fun setCustomApiKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CUSTOM_API_KEY, key.trim())
            .apply()
    }

    fun getVaultPin(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_VAULT_PIN, "") ?: ""
    }

    fun setVaultPin(context: Context, pin: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_VAULT_PIN, pin.trim())
            .apply()
    }

    fun isPinLockEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PIN_ENABLED, false)
    }

    fun setPinLockEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_PIN_ENABLED, enabled)
            .apply()
    }

    fun getThemeMode(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_THEME_MODE, "dark") ?: "dark" // Default to a gorgeous dark dynamic theme!
    }

    fun setThemeMode(context: Context, mode: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME_MODE, mode)
            .apply()
    }
}
