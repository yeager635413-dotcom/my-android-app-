package com.example.api

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    val mimeType: String,
    val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content?
)

@JsonClass(generateAdapter = true)
data class ScannedDocumentResult(
    val title: String,
    val category: String,
    val extractedText: String,
    val summary: String,
    val keyDetails: String
)

object GeminiClient {
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        // Compress to JPEG with high quality
        compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeDocument(bitmap: Bitmap, customApiKey: String? = null): ScannedDocumentResult? = withContext(Dispatchers.IO) {
        var apiKey = if (!customApiKey.isNullOrBlank()) customApiKey else BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Fallback or handle missing API key error gracefully
            throw IllegalStateException("Gemini API key is not configured. Please capture your key in Document Vault Settings or the AI Studio Secrets panel.")
        }

        val promptText = """
            Analyze this scanned paper document image. Extract ALL text inside the document using OCR.
            In addition to performing a direct raw OCR extraction, you must analyze its content and output a structured JSON containing:
            1. "title": Estimate a suitable short, descriptive file title for this document (e.g., "Starbucks Receipt", "State ID: John Doe", "Blood Test Report", "Lease Contract").
            2. "category": Categorize this document into exactly ONE of these options:
               - "Receipts & Invoices" (for purchases, bills, receipts, invoices)
               - "Identity & Cards" (for ID card, passport, driver's license, insurance card)
               - "Medical & Health" (for medical reports, prescriptions, test results)
               - "Academic & Certs" (for diplomas, course certificates, grade card, school report)
               - "Work & Professional" (for business contract, notes, resumes, corporate paperwork)
               - "Others" (if it doesn't fit any of the above)
            3. "extractedText": The complete, raw OCR extraction of all text readable from the image. Do not omit any details, tables, or numbers.
            4. "summary": A concise, structured 1-2 sentence high-level summary explaining what the document is and what it reveals.
            5. "keyDetails": A concise, bulleted markdown summary of key details (e.g., • Date: ... \n • Amount: ... \n • Document ID: ... \n • Key Entity: ...).

            Ensure the response is valid structured JSON matching the keys exactly.
        """.trimIndent()

        val systemInstructionText = "You are an expert AI document scanner, archivist, and optical character recognition (OCR) engine. You return highly accurate structured representations of digital paper copies."

        val requestBody = GeminiRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = promptText),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = bitmap.toBase64()))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json"
            ),
            systemInstruction = Content(
                parts = listOf(Part(text = systemInstructionText))
            )
        )

        try {
            val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
            val requestJson = jsonAdapter.toJson(requestBody)

            val httpRequestBody = requestJson.toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(httpRequestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext null
            }

            val responseBodyString = response.body?.string() ?: return@withContext null
            val responseAdapter = moshi.adapter(GeminiResponse::class.java)
            val geminiResponse = responseAdapter.fromJson(responseBodyString)

            val rawResultText = geminiResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: return@withContext null

            // Now parse the structured OCR response
            val resultAdapter = moshi.adapter(ScannedDocumentResult::class.java)
            return@withContext resultAdapter.fromJson(rawResultText)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
