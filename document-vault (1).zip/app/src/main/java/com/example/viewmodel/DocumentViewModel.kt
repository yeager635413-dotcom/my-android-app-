package com.example.viewmodel

import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.database.AppDatabase
import com.example.database.Document
import com.example.database.DocumentRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

sealed interface ScanState {
    object Idle : ScanState
    object Processing : ScanState
    data class Success(val document: Document) : ScanState
    data class Error(val message: String) : ScanState
}

class DocumentViewModel(
    private val repository: DocumentRepository,
    private val appContext: Context
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    // Combined Flow for reactive and fast listing/searching with Support for Pinning and Custom Notes Search
    val documentsState: StateFlow<List<Document>> = combine(
        repository.allDocuments,
        _searchQuery,
        _selectedCategory
    ) { allDocs, query, category ->
        allDocs.filter { doc ->
            // Support a special category "Favorites" for quick lookup
            val matchesCategory = when (category) {
                "All" -> true
                "Favorites" -> doc.isFavorite
                "Secure Vault" -> doc.isLocked
                else -> doc.category.equals(category, ignoreCase = true)
            }
            val matchesSearch = query.isEmpty() ||
                    doc.title.contains(query, ignoreCase = true) ||
                    doc.extractedText.contains(query, ignoreCase = true) ||
                    doc.summary.contains(query, ignoreCase = true) ||
                    doc.keyDetails.contains(query, ignoreCase = true) ||
                    doc.notes.contains(query, ignoreCase = true)
            matchesCategory && matchesSearch
        }.sortedWith(compareByDescending<Document> { it.isPinned }.thenByDescending { it.dateAdded })
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Support Vault lock screen state
    private val _isVaultUnlocked = MutableStateFlow(!com.example.api.VaultSettings.isPinLockEnabled(appContext))
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    fun verifyPinAndUnlock(pin: String): Boolean {
        val savedPin = com.example.api.VaultSettings.getVaultPin(appContext)
        return if (pin == savedPin) {
            _isVaultUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockVault() {
        if (com.example.api.VaultSettings.isPinLockEnabled(appContext)) {
            _isVaultUnlocked.value = false
        }
    }

    fun resetLockState() {
        _isVaultUnlocked.value = !com.example.api.VaultSettings.isPinLockEnabled(appContext)
    }

    // Toggle Favorite
    fun toggleFavorite(document: Document) {
        viewModelScope.launch {
            repository.insertDocument(document.copy(isFavorite = !document.isFavorite))
        }
    }

    // Toggle Pinned
    fun togglePinned(document: Document) {
        viewModelScope.launch {
            repository.insertDocument(document.copy(isPinned = !document.isPinned))
        }
    }

    // Toggle Locked
    fun toggleLocked(document: Document) {
        viewModelScope.launch {
            repository.insertDocument(document.copy(isLocked = !document.isLocked))
        }
    }

    // Update document fully (e.g. customized edits)
    fun updateDocument(document: Document) {
        viewModelScope.launch {
            repository.insertDocument(document)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun clearScanState() {
        _scanState.value = ScanState.Idle
    }

    fun processScannedImage(bitmap: Bitmap) {
        viewModelScope.launch {
            _scanState.value = ScanState.Processing
            try {
                // Read custom API key from settings (if any)
                val userKey = com.example.api.VaultSettings.getCustomApiKey(appContext)
                // Call Gemini for high-level OCR & Categorization
                val analysisResult = GeminiClient.analyzeDocument(bitmap, userKey)
                
                if (analysisResult == null) {
                    _scanState.value = ScanState.Error("Failed to extract content. Please ensure document has sharp text and is not blurry, then try again.")
                    return@launch
                }

                // Save image locally offline in files space
                val savedLocalPath = saveBitmapToInternalStorage(bitmap)
                if (savedLocalPath == null) {
                    _scanState.value = ScanState.Error("Failed to cache digital copy locally on device storage.")
                    return@launch
                }

                val doc = Document(
                    title = analysisResult.title,
                    category = analysisResult.category,
                    imagePath = savedLocalPath,
                    extractedText = analysisResult.extractedText,
                    summary = analysisResult.summary,
                    keyDetails = analysisResult.keyDetails,
                    isFavorite = false,
                    isPinned = false,
                    isLocked = false,
                    notes = ""
                )

                // Save to Room DB
                repository.insertDocument(doc)
                _scanState.value = ScanState.Success(doc)
            } catch (e: Exception) {
                _scanState.value = ScanState.Error(e.message ?: "An unexpected analysis failure occurred.")
            }
        }
    }

    fun deleteDocument(document: Document) {
        viewModelScope.launch {
            // Delete record from DB
            repository.deleteDocument(document)
            // Delete file from local file storage
            try {
                val file = File(document.imagePath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            val docs = documentsState.value
            docs.forEach { doc ->
                // Delete file from local file storage
                try {
                    val file = File(doc.imagePath)
                    if (file.exists()) {
                        file.delete()
                    }
                } catch (e: Exception) {}
                repository.deleteDocument(doc)
            }
        }
    }

    fun clearAllDocuments() {
        viewModelScope.launch {
            val docs = documentsState.value
            docs.forEach { doc ->
                // Delete file from local file storage
                try {
                    val file = File(doc.imagePath)
                    if (file.exists()) {
                        file.delete()
                    }
                } catch (e: Exception) {}
                repository.deleteDocument(doc)
            }
        }
    }

    private fun saveBitmapToInternalStorage(bitmap: Bitmap): String? {
        return try {
            val directory = File(appContext.filesDir, "locked_documents")
            if (!directory.exists()) {
                directory.mkdirs()
            }
            val fileName = "doc_${System.currentTimeMillis()}.jpg"
            val file = File(directory, fileName)
            FileOutputStream(file).use { outStream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outStream)
            }
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Factory Class pattern
    class Factory(
        private val repository: DocumentRepository,
        private val context: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DocumentViewModel::class.java)) {
                return DocumentViewModel(repository, context) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
